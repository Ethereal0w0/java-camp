package com.example.sotrailways;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SotrailwaysApplicationTests {

	@Test
	void contextLoads() {
	}

}
