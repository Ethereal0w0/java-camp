package com.example.sotrailways;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SotrailwaysApplication {

	public static void main(String[] args) {
		SpringApplication.run(SotrailwaysApplication.class, args);
	}

}
